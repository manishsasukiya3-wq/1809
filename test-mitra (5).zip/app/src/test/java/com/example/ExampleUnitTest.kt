package com.example

import com.example.data.model.TestItem
import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDateConversionToDdMmYyyy() {
    val t1 = TestItem(testDate = "2025-01-20", testDay = "Sunday")
    assertEquals("20/01/2025 • Sunday", t1.getFormattedDate())

    val t2 = TestItem(testDate = "20/01/2025")
    assertEquals("20/01/2025", t2.getFormattedDate())

    val t3 = TestItem(createdAt = "2026-09-07T12:08:46.426164+00:00")
    assertEquals("07/09/2026", t3.getFormattedDate())

    val t4 = TestItem(createdAt = "2026-09-07T12:08:46.426164+00:00", testDay = "Monday")
    assertEquals("07/09/2026 • Monday", t4.getFormattedDate())

    val t5 = TestItem(testDate = "7-9-2026")
    assertEquals("07/09/2026", t5.getFormattedDate())
  }

  @Test
  fun testSearchByNameDateAndDay() {
    val test = TestItem(
        testName = "Mathematics Mock Exam",
        testDate = "2025-01-20",
        testDay = "Sunday"
    )

    // Name search
    assertTrue(test.matchesSearch("Math"))
    assertTrue(test.matchesSearch("mock"))
    assertTrue(test.matchesSearch("exam"))
    assertFalse(test.matchesSearch("Physics"))

    // Date search (dd/MM/yyyy format, partial, raw)
    assertTrue(test.matchesSearch("20/01/2025"))
    assertTrue(test.matchesSearch("20/01"))
    assertTrue(test.matchesSearch("20-01-2025"))
    assertTrue(test.matchesSearch("2025-01-20"))
    assertTrue(test.matchesSearch("2025"))
    assertFalse(test.matchesSearch("21/01/2025"))

    // Day search (English and Gujarati aliases)
    assertTrue(test.matchesSearch("Sunday"))
    assertTrue(test.matchesSearch("Sun"))
    assertTrue(test.matchesSearch("sunday"))
    assertTrue(test.matchesSearch("રવિવાર"))
    assertTrue(test.matchesSearch("રવિ"))
    assertFalse(test.matchesSearch("Monday"))
    assertFalse(test.matchesSearch("સોમવાર"))
  }
}

