package com.example.ui.screens.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PassageItem
import com.example.data.model.QuestionItem
import com.example.data.model.TestItem
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

/**
 * Clean, range-based Passage Management component for Admin.
 * Supports:
 * 1. Selecting test
 * 2. Creating a passage once for multiple questions (Q1–Q5, Q6–Q9, etc.)
 * 3. Editing existing passage text and question range
 * 4. Deleting passage records without touching questions or test data
 * 5. Automatic overlap detection and clear validation
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPassageManagementContent(
    testsList: List<TestItem>,
    repository: TestMitraRepository,
    initialTestId: Long? = null,
    onPassagesChanged: () -> Unit = {}
) {
    var selectedTestId by remember {
        mutableStateOf<Long?>(initialTestId ?: testsList.firstOrNull()?.id)
    }
    var testDropdownExpanded by remember { mutableStateOf(false) }

    var questionsList by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var passagesList by remember { mutableStateOf<List<PassageItem>>(emptyList()) }
    var isLoadingData by remember { mutableStateOf(false) }

    // Form inputs
    var passageText by remember { mutableStateOf("") }
    var startingQuestionOrder by remember { mutableIntStateOf(1) }
    var questionCount by remember { mutableIntStateOf(1) }
    var editingPassageId by remember { mutableStateOf<Long?>(null) }

    var startQuestionDropdownExpanded by remember { mutableStateOf(false) }
    var countDropdownExpanded by remember { mutableStateOf(false) }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    // Delete modal
    var passageToDelete by remember { mutableStateOf<PassageItem?>(null) }
    var isDeleting by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    // Function to reload questions and passages for selected test
    val reloadData: () -> Unit = {
        val tId = selectedTestId
        if (tId != null && tId > 0L) {
            isLoadingData = true
            scope.launch {
                val qRes = repository.getQuestionsForTest(tId)
                if (qRes is Resource.Success) {
                    questionsList = qRes.data
                }
                val pRes = repository.getPassagesForTest(tId)
                if (pRes is Resource.Success) {
                    passagesList = pRes.data
                }
                isLoadingData = false
            }
        } else {
            questionsList = emptyList()
            passagesList = emptyList()
        }
    }

    LaunchedEffect(selectedTestId) {
        // Reset form when changing test
        passageText = ""
        startingQuestionOrder = 1
        questionCount = 1
        editingPassageId = null
        errorMessage = null
        successMessage = null
        reloadData()
    }

    val totalQuestions = questionsList.size
    val maxAvailableCount = if (totalQuestions > 0) {
        (totalQuestions - startingQuestionOrder + 1).coerceAtLeast(1)
    } else {
        1
    }

    // Keep count within bounds
    LaunchedEffect(startingQuestionOrder, totalQuestions) {
        if (questionCount > maxAvailableCount) {
            questionCount = maxAvailableCount
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Test Selection (if more than 1 test exists or initial not forced)
        if (testsList.isNotEmpty()) {
            val currTest = testsList.firstOrNull { it.id == selectedTestId }
            ExposedDropdownMenuBox(
                expanded = testDropdownExpanded,
                onExpandedChange = { testDropdownExpanded = !testDropdownExpanded }
            ) {
                OutlinedTextField(
                    value = currTest?.let { "${it.testName} (${it.duration} min)" } ?: "Select Test",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Test for Passage") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = testDropdownExpanded) },
                    modifier = Modifier
                        .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = testDropdownExpanded,
                    onDismissRequest = { testDropdownExpanded = false }
                ) {
                    testsList.forEach { t ->
                        val isSelected = t.id == selectedTestId
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = t.testName,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MitraNavyPrimary else MitraTextPrimary
                                )
                            },
                            onClick = {
                                selectedTestId = t.id
                                testDropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }

        if (isLoadingData) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MitraNavyPrimary, modifier = Modifier.size(32.dp))
            }
        } else if (totalQuestions == 0) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MitraBgLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MitraTextMuted)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "This test has no questions yet. Please add questions first before assigning passages.",
                        fontSize = 13.sp,
                        color = MitraTextSecondary
                    )
                }
            }
        } else {
            // Existing Passages for this Test
            if (passagesList.isNotEmpty()) {
                Text(
                    text = "Existing Passages (${passagesList.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MitraNavyPrimary
                )

                passagesList.forEach { passage ->
                    val pStartIdx = questionsList.indexOfFirst { it.id == passage.questionId }
                        .takeIf { it >= 0 }
                        ?: (passage.questionId?.toInt()?.let { it - 1 }?.takeIf { it in questionsList.indices } ?: 0)
                    val pStartNum = pStartIdx + 1

                    val pEndIdx = if (passage.endQuestionId != null) {
                        questionsList.indexOfFirst { it.id == passage.endQuestionId }
                            .takeIf { it >= 0 }
                            ?: (passage.endQuestionId.toInt()?.let { it - 1 }?.takeIf { it in pStartIdx until questionsList.size } ?: pStartIdx)
                    } else {
                        pStartIdx
                    }
                    val pEndNum = pEndIdx + 1
                    val rangeText = if (pStartNum == pEndNum) "Q$pStartNum" else "Q$pStartNum–Q$pEndNum"
                    val isEditingThis = editingPassageId == passage.id

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isEditingThis) Color(0xFFEFF6FF) else Color.White
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (isEditingThis) MitraNavyPrimary else MitraBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isEditingThis) MitraNavyPrimary else MitraGreen
                                ) {
                                    Text(
                                        text = "Passage ($rangeText)",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = {
                                            // Load into edit mode
                                            editingPassageId = passage.id
                                            passageText = passage.getEffectiveText()
                                            startingQuestionOrder = pStartNum
                                            questionCount = (pEndNum - pStartNum + 1).coerceAtLeast(1)
                                            errorMessage = null
                                            successMessage = null
                                        },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit Passage",
                                            tint = MitraNavyPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            passageToDelete = passage
                                        },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete Passage",
                                            tint = MitraError,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = passage.getEffectiveText(),
                                fontSize = 13.sp,
                                color = MitraTextPrimary,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                HorizontalDivider(color = MitraBorder, thickness = 1.dp)
            }

            // ADD / EDIT PASSAGE FORM CARD
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, MitraBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (editingPassageId != null) "Edit Passage" else "Add Passage",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraNavyPrimary
                        )

                        if (editingPassageId != null) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MitraNavyPrimary.copy(alpha = 0.1f),
                                modifier = Modifier.clickable {
                                    editingPassageId = null
                                    passageText = ""
                                    startingQuestionOrder = 1
                                    questionCount = 1
                                    errorMessage = null
                                    successMessage = null
                                }
                            ) {
                                Text(
                                    text = "Cancel Edit",
                                    color = MitraNavyPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // 1. Passage Text field
                    OutlinedTextField(
                        value = passageText,
                        onValueChange = {
                            passageText = it
                            errorMessage = null
                            successMessage = null
                        },
                        label = { Text("Passage") },
                        placeholder = { Text("Read the following passage carefully...") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passage_input_field")
                    )

                    // 2. Starting Question: "કયા Questionથી શરૂ કરવો છે?"
                    ExposedDropdownMenuBox(
                        expanded = startQuestionDropdownExpanded,
                        onExpandedChange = { startQuestionDropdownExpanded = !startQuestionDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "Question $startingQuestionOrder",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("કયા Questionથી શરૂ કરવો છે?") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = startQuestionDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                .fillMaxWidth()
                                .testTag("start_question_dropdown")
                        )
                        ExposedDropdownMenu(
                            expanded = startQuestionDropdownExpanded,
                            onDismissRequest = { startQuestionDropdownExpanded = false }
                        ) {
                            (1..totalQuestions).forEach { qNum ->
                                val isSelected = qNum == startingQuestionOrder
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "Question $qNum",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        startingQuestionOrder = qNum
                                        startQuestionDropdownExpanded = false
                                        errorMessage = null
                                        successMessage = null
                                    }
                                )
                            }
                        }
                    }

                    // 3. Question Count: "આ Passage કેટલા Questions માટે રાખવો છે?"
                    ExposedDropdownMenuBox(
                        expanded = countDropdownExpanded,
                        onExpandedChange = { countDropdownExpanded = !countDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "$questionCount",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("આ Passage કેટલા Questions માટે રાખવો છે?") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = countDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                .fillMaxWidth()
                                .testTag("question_count_dropdown")
                        )
                        ExposedDropdownMenu(
                            expanded = countDropdownExpanded,
                            onDismissRequest = { countDropdownExpanded = false }
                        ) {
                            (1..maxAvailableCount).forEach { count ->
                                val isSelected = count == questionCount
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "$count ${if (count == 1) "Question" else "Questions"}",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        questionCount = count
                                        countDropdownExpanded = false
                                        errorMessage = null
                                        successMessage = null
                                    }
                                )
                            }
                        }
                    }

                    // Dynamic Scope Summary: Q1 to Q5 preview
                    val endQuestionOrder = startingQuestionOrder + questionCount - 1
                    val affectedQuestions = (startingQuestionOrder..endQuestionOrder).joinToString(", ") { "Q$it" }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MitraBgLight,
                        border = BorderStroke(1.dp, MitraBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(4.dp), color = MitraNavyPrimary) {
                                    Text(
                                        text = if (startingQuestionOrder == endQuestionOrder) "Q$startingQuestionOrder" else "Q$startingQuestionOrder–Q$endQuestionOrder",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "આ Passage Q$startingQuestionOrder થી Q$endQuestionOrder માટે લાગુ પડશે",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MitraNavyPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "લાગુ પડતા Questions: $affectedQuestions",
                                fontSize = 11.sp,
                                color = MitraTextSecondary
                            )
                        }
                    }

                    // Error message banner
                    if (errorMessage != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MitraErrorLight,
                            border = BorderStroke(1.dp, MitraError.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = MitraError, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = errorMessage!!,
                                    color = MitraError,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Success message banner
                    if (successMessage != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MitraGreenLight,
                            border = BorderStroke(1.dp, MitraGreen.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = successMessage!!,
                                    color = MitraGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Submit button: [ Save Passage ] / [ Update Passage ]
                    MitraPrimaryButton(
                        text = if (editingPassageId != null) "Update Passage" else "Save Passage",
                        onClick = {
                            val tId = selectedTestId ?: return@MitraPrimaryButton
                            val cleanText = passageText.trim()
                            if (cleanText.isBlank()) {
                                errorMessage = "Passage text cannot be empty."
                                return@MitraPrimaryButton
                            }

                            isSaving = true
                            errorMessage = null
                            successMessage = null

                            scope.launch {
                                val result = repository.savePassageRange(
                                    testId = tId,
                                    passageText = cleanText,
                                    startQuestionOrder = startingQuestionOrder,
                                    questionCount = questionCount,
                                    existingPassageId = editingPassageId
                                )
                                isSaving = false
                                if (result is Resource.Success) {
                                    val savedRange = if (startingQuestionOrder == endQuestionOrder) "Q$startingQuestionOrder" else "Q$startingQuestionOrder–Q$endQuestionOrder"
                                    successMessage = if (editingPassageId != null) {
                                        "Passage updated successfully for $savedRange!"
                                    } else {
                                        "Passage saved successfully for $savedRange!"
                                    }
                                    passageText = ""
                                    startingQuestionOrder = 1
                                    questionCount = 1
                                    editingPassageId = null
                                    reloadData()
                                    onPassagesChanged()
                                } else if (result is Resource.Error) {
                                    errorMessage = result.message
                                }
                            }
                        },
                        isLoading = isSaving,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_passage_button")
                    )
                }
            }
        }
    }

    // Modal: Confirmation Dialog for Passage Deletion
    if (passageToDelete != null) {
        val p = passageToDelete!!
        val pStartIdx = questionsList.indexOfFirst { it.id == p.questionId }
            .takeIf { it >= 0 }
            ?: (p.questionId?.toInt()?.let { it - 1 }?.takeIf { it in questionsList.indices } ?: 0)
        val pStartNum = pStartIdx + 1
        val pEndIdx = if (p.endQuestionId != null) {
            questionsList.indexOfFirst { it.id == p.endQuestionId }
                .takeIf { it >= 0 }
                ?: (p.endQuestionId.toInt()?.let { it - 1 }?.takeIf { it in pStartIdx until questionsList.size } ?: pStartIdx)
        } else {
            pStartIdx
        }
        val pEndNum = pEndIdx + 1
        val pRange = if (pStartNum == pEndNum) "Q$pStartNum" else "Q$pStartNum–Q$pEndNum"

        AlertDialog(
            onDismissRequest = { if (!isDeleting) passageToDelete = null },
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            icon = {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = MitraError,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Delete Passage ($pRange)?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MitraError
                )
            },
            text = {
                Text(
                    text = "This will only remove the passage record for $pRange. The questions, answers, and test data will NOT be deleted.",
                    fontSize = 13.sp,
                    color = MitraTextSecondary,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Delete Passage",
                    onClick = {
                        val pid = p.id ?: return@MitraPrimaryButton
                        isDeleting = true
                        scope.launch {
                            val res = repository.deletePassage(pid)
                            isDeleting = false
                            if (res is Resource.Success) {
                                passageToDelete = null
                                if (editingPassageId == pid) {
                                    editingPassageId = null
                                    passageText = ""
                                }
                                reloadData()
                                onPassagesChanged()
                            } else if (res is Resource.Error) {
                                errorMessage = res.message
                                passageToDelete = null
                            }
                        }
                    },
                    isLoading = isDeleting,
                    containerColor = MitraError
                )
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { passageToDelete = null },
                    enabled = !isDeleting
                ) {
                    Text("Cancel", color = MitraTextSecondary)
                }
            }
        )
    }
}

/**
 * Modal Dialog for managing Passages of a specific test.
 */
@Composable
fun AdminManagePassagesDialog(
    test: TestItem,
    testsList: List<TestItem>,
    repository: TestMitraRepository,
    onDismiss: () -> Unit,
    onPassagesChanged: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp)
            .testTag("admin_manage_passages_dialog"),
        shape = RoundedCornerShape(20.dp),
        containerColor = Color.White,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Manage Passages",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraNavyPrimary
                    )
                    Text(
                        text = test.testName,
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Clear, contentDescription = "Close")
                }
            }
        },
        text = {
            Box(modifier = Modifier.height(480.dp)) {
                AdminPassageManagementContent(
                    testsList = listOf(test),
                    repository = repository,
                    initialTestId = test.id,
                    onPassagesChanged = onPassagesChanged
                )
            }
        },
        confirmButton = {
            MitraPrimaryButton(text = "Done", onClick = onDismiss)
        }
    )
}
