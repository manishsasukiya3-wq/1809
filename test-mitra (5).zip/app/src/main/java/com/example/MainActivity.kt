package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.SessionManager
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.NoInternetDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.admin.AdminHomeScreen
import com.example.ui.screens.student.StudentHomeScreen
import com.example.ui.screens.student.TakeTestScreen
import com.example.ui.screens.student.TestResultScreen
import com.example.ui.theme.TestMitraTheme
import com.example.util.NetworkMonitor
import kotlinx.coroutines.launch

enum class AppDestination {
    SPLASH,
    LOGIN,
    STUDENT_HOME,
    ADMIN_HOME,
    TAKE_TEST,
    TEST_RESULT
}

class MainActivity : ComponentActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var clientProvider: SupabaseClientProvider
    private lateinit var repository: TestMitraRepository
    private lateinit var networkMonitor: NetworkMonitor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        sessionManager = SessionManager(applicationContext)
        clientProvider = SupabaseClientProvider(sessionManager)
        repository = TestMitraRepository(clientProvider)
        networkMonitor = NetworkMonitor(applicationContext)

        setContent {
            TestMitraTheme {
                TestMitraApp(
                    sessionManager = sessionManager,
                    clientProvider = clientProvider,
                    repository = repository,
                    networkMonitor = networkMonitor
                )
            }
        }
    }
}

@Composable
fun TestMitraApp(
    sessionManager: SessionManager,
    clientProvider: SupabaseClientProvider,
    repository: TestMitraRepository,
    networkMonitor: NetworkMonitor
) {
    var currentDestination by remember { mutableStateOf(AppDestination.SPLASH) }
    var currentUser by remember { mutableStateOf<User?>(null) }

    // Test Taking State
    var activeTestId by remember { mutableLongStateOf(0L) }
    var activeTestName by remember { mutableStateOf("") }
    var activeTestDuration by remember { mutableIntStateOf(15) }

    // Test Result State
    var resultTotalQuestions by remember { mutableIntStateOf(0) }
    var resultCorrectCount by remember { mutableIntStateOf(0) }
    var resultScore by remember { mutableDoubleStateOf(0.0) }
    var resultAnswersJson by remember { mutableStateOf("{}") }

    val scope = rememberCoroutineScope()
    val isOnline by networkMonitor.isOnlineFlow.collectAsStateWithLifecycle(initialValue = networkMonitor.isCurrentlyConnected())
    var showNoInternetDialog by remember { mutableStateOf(false) }

    LaunchedEffect(isOnline) {
        showNoInternetDialog = !isOnline
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            when (currentDestination) {
                AppDestination.SPLASH -> {
                    SplashScreen(
                        sessionManager = sessionManager,
                        repository = repository,
                        onNavigateToLogin = {
                            currentDestination = AppDestination.LOGIN
                        },
                        onNavigateToStudentHome = {
                            currentUser = sessionManager.getUser()
                            currentDestination = AppDestination.STUDENT_HOME
                        },
                        onNavigateToAdminHome = {
                            currentUser = sessionManager.getUser()
                            currentDestination = AppDestination.ADMIN_HOME
                        }
                    )
                }

                AppDestination.LOGIN -> {
                    LoginScreen(
                        repository = repository,
                        sessionManager = sessionManager,
                        clientProvider = clientProvider,
                        onLoginSuccess = { loggedInUser ->
                            currentUser = loggedInUser
                            if (loggedInUser.isTeacherOrAdmin) {
                                currentDestination = AppDestination.ADMIN_HOME
                            } else {
                                currentDestination = AppDestination.STUDENT_HOME
                            }
                        }
                    )
                }

                AppDestination.STUDENT_HOME -> {
                    val studentUser = currentUser ?: sessionManager.getUser()
                    if (studentUser != null) {
                        StudentHomeScreen(
                            user = studentUser,
                            repository = repository,
                            sessionManager = sessionManager,
                            onStartTest = { testId, testName, duration ->
                                activeTestId = testId
                                activeTestName = testName
                                activeTestDuration = duration
                                currentDestination = AppDestination.TAKE_TEST
                            },
                            onLogout = {
                                currentUser = null
                                currentDestination = AppDestination.LOGIN
                            }
                        )
                    } else {
                        LaunchedEffect(Unit) {
                            currentDestination = AppDestination.LOGIN
                        }
                    }
                }

                AppDestination.ADMIN_HOME -> {
                    val adminUser = currentUser ?: sessionManager.getUser()
                    if (adminUser != null) {
                        AdminHomeScreen(
                            user = adminUser,
                            repository = repository,
                            sessionManager = sessionManager,
                            onTakeTest = { testId, testName, duration ->
                                // Feature 1: Admin / Super Admin taking test
                                activeTestId = testId
                                activeTestName = testName
                                activeTestDuration = duration
                                currentDestination = AppDestination.TAKE_TEST
                            },
                            onLogout = {
                                currentUser = null
                                currentDestination = AppDestination.LOGIN
                            }
                        )
                    } else {
                        LaunchedEffect(Unit) {
                            currentDestination = AppDestination.LOGIN
                        }
                    }
                }

                AppDestination.TAKE_TEST -> {
                    val activeUser = currentUser ?: sessionManager.getUser()
                    if (activeUser != null) {
                        TakeTestScreen(
                            testId = activeTestId,
                            testName = activeTestName,
                            durationMinutes = activeTestDuration,
                            user = activeUser,
                            repository = repository,
                            onTestFinished = { testId, testName, total, correct, score, answersJson ->
                                activeTestId = testId
                                activeTestName = testName
                                resultTotalQuestions = total
                                resultCorrectCount = correct
                                resultScore = score
                                resultAnswersJson = answersJson
                                currentDestination = AppDestination.TEST_RESULT
                            },
                            onCancelTest = {
                                // Return to appropriate dashboard based on user role
                                if (activeUser.isTeacherOrAdmin) {
                                    currentDestination = AppDestination.ADMIN_HOME
                                } else {
                                    currentDestination = AppDestination.STUDENT_HOME
                                }
                            }
                        )
                    }
                }

                AppDestination.TEST_RESULT -> {
                    val activeUser = currentUser ?: sessionManager.getUser()
                    TestResultScreen(
                        testId = activeTestId,
                        testName = activeTestName,
                        totalQuestions = resultTotalQuestions,
                        correctCount = resultCorrectCount,
                        score = resultScore,
                        answersMapJson = resultAnswersJson,
                        repository = repository,
                        onBackToHome = {
                            if (activeUser?.isTeacherOrAdmin == true) {
                                currentDestination = AppDestination.ADMIN_HOME
                            } else {
                                currentDestination = AppDestination.STUDENT_HOME
                            }
                        },
                        onRetakeTest = {
                            currentDestination = AppDestination.TAKE_TEST
                        }
                    )
                }
            }

            // Mandatory Internet Check Dialog
            if (showNoInternetDialog) {
                NoInternetDialog(
                    onRetry = {
                        showNoInternetDialog = !networkMonitor.isCurrentlyConnected()
                    }
                )
            }
        }
    }
}
